#include <iostream>
#include <string>
using namespace std;

int main()
{
    //set number of digits after decimal point to 2
    cout.setf(ios::fixed);
    cout.precision(2);

    //ask for and obtain input for cheese type from user, store in a string
    cout << "Cheese type: ";
    string cheeseType;
    getline(cin, cheeseType);
    
    //ask for and obtain input for value from user, store in a variable of type double
    cout << "Value: ";
    double value;
    cin >> value;
    cin.ignore(10000, '\n');
    
    //ask for and obtain input for importer from user, store in a string
    cout << "Importer: ";
    string importer;
    getline(cin, importer);
    
    //output 3 hyphens as specified
    cout << "---" << endl;
    
    //define a variable of type double to store the value of duty on cheese
    double duty{};
    
    //calculate value of duty on cheese that is $1000 or less
    if (value <= 1000)
    {
        duty = 0.011 * value;
    }
    
    //calculate value of duty on cheese valued at less than or equal to $13000 and greater than $1000
    //1.1% duty for first $1000 and 2% on the next $12000
    if (value <= 13000 && value > 1000)
    {
        duty = (0.011 * 1000) + (0.02 * (value - 1000));
        
        //cheshire and stilton have 1.1% duty on the first $1000 and 1.4% duty on the next $12000
        if (cheeseType == "cheshire" || cheeseType == "stilton")
        {
            duty = (0.011 * 1000) + (0.014 * (value - 1000));
        }
    }
    
    //calculate value of duty on cheese valued at more than $13000
    //1.1% duty for first $1000, 2% on additional $12000 and 2.9% on amount that exceeds $13000
    if (value > 13000)
    {
        duty = (0.011 * 1000) + (12000 * 0.02) + (0.029 * (value - 13000));
        
        //cheshire and stilton have 1.1% duty on the first $1000, 1.4% duty on the next $12000 and 2.9% on value that exceeds $13000
        if (cheeseType == "cheshire" || cheeseType == "stilton")
        {
            duty = (0.011 * 1000) + (0.014 * 12000) + (0.029 * (value - 13000));
        }
    }
    
    //check that user did not enter empty string for cheese type
    if (cheeseType == "")
    {
        cout << "You must enter a cheese type" << endl;
    }
    
    //check that user did not enter non positive value for value
    else if (value <= 0)
    {
        cout << "The value must be positive" << endl;;
    }
    
    //check that user did not enter empty string for importer
    else if (importer == "")
    {
        cout << "You must enter an importer" << endl;
    }
    
    //if all input is valid, print importer and duty amount
    else
    {
        cout << "The import duty for " << importer << " is $" << duty << endl;
    }
}
